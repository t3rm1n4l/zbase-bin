/* -*- Mode: C; tab-width: 4; c-basic-offset: 4; indent-tabs-mode: nil -*- */

/*
 *   Copyright 2013 Zynga, Inc.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */
#ifndef MEMCACHED_EXTENSION_LOGGERS_H
#define MEMCACHED_EXTENSION_LOGGERS_H
#include <memcached/extension.h>

#ifdef  __cplusplus
extern "C" {
#endif

MEMCACHED_PUBLIC_API EXTENSION_LOGGER_DESCRIPTOR* get_null_logger(void);

MEMCACHED_PUBLIC_API EXTENSION_LOGGER_DESCRIPTOR* get_stderr_logger(void);

MEMCACHED_PUBLIC_API
EXTENSION_ERROR_CODE memcached_initialize_stderr_logger(GET_SERVER_API get_server_api);

#ifdef  __cplusplus
}
#endif

#endif  /* MEMCACHED_EXTENSION_LOGGER_H */
